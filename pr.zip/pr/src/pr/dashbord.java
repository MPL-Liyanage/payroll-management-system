package pr;


import com.itextpdf.text.Document;

import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;

import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfPTable;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import java.io.FileOutputStream;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ASUS
 */
public class dashbord extends javax.swing.JFrame {
    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pat = null;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(dashbord.class.getName());

    /**
     * Creates new form dashbord
     */
    public dashbord() {
        initComponents();
        conn = db.java_db();
        showDate();
        showTime();
        lbl_emp.setText(String.valueOf(emp.empid).toString());
        
        
    }
    private void generateEmployeeReport() {
    JFileChooser dialog = new JFileChooser();
    dialog.setSelectedFile(new File("Employees Report.pdf"));
    if (dialog.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
        String filePath = dialog.getSelectedFile().getPath();
        try {
            String sql = "SELECT * FROM employee";
            PreparedStatement pat = conn.prepareStatement(sql);
            ResultSet rs = pat.executeQuery();

            Document myDocument = new Document();
            PdfWriter.getInstance(myDocument, new FileOutputStream(filePath));
            myDocument.open();

            com.itextpdf.text.Font headerFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.BOLD);
            com.itextpdf.text.Font cellFont   = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.PLAIN);

            PdfPTable table = new PdfPTable(12);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{3,8,7,5,5,9,8,9,6,6,6,8});

            myDocument.add(new Paragraph("Employees Report",
                    FontFactory.getFont(FontFactory.TIMES_BOLD, 20, Font.BOLD)));
            myDocument.add(new Paragraph(
                    new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date())
            ));
            myDocument.add(new Paragraph("----------------------------------------------------------"));

            String[] headers = {"ID","First Name","Surname","Date of Birth","Email",
                                "Telephone","Address","Department","Gender","Salary",
                                "Date Hired","Job Title"};
            for (String h : headers) {
                table.addCell(new PdfPCell(new Paragraph(h, headerFont)));
            }

            while (rs.next()) {
                for (int i = 1; i <= 12; i++) {
                    table.addCell(new PdfPCell(new Paragraph(rs.getString(i), cellFont)));
                }
            }

            myDocument.add(table);
            myDocument.close();
            JOptionPane.showMessageDialog(null, "Employee Report Generated");

            rs.close();
            pat.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}

private void generateAllowanceReport() {
    JFileChooser dialog = new JFileChooser();
    dialog.setSelectedFile(new File("Allowance Report.pdf"));
    if (dialog.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
        String filePath = dialog.getSelectedFile().getPath();
        try {
            String sql = "SELECT * FROM allowance";
            PreparedStatement pat = conn.prepareStatement(sql);
            ResultSet rs = pat.executeQuery();

            Document myDocument = new Document();
            PdfWriter.getInstance(myDocument, new FileOutputStream(filePath));
            myDocument.open();

            com.itextpdf.text.Font headerFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.BOLD);
            com.itextpdf.text.Font cellFont   = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.PLAIN);

            PdfPTable table = new PdfPTable(rs.getMetaData().getColumnCount());
            table.setWidthPercentage(100);

            myDocument.add(new Paragraph("Allowance Report",
                    FontFactory.getFont(FontFactory.TIMES_BOLD, 20, Font.BOLD)));
            myDocument.add(new Paragraph(
                    new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date())
            ));
            myDocument.add(new Paragraph("----------------------------------------------------------"));

            // Headers
            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                table.addCell(new PdfPCell(new Paragraph(rs.getMetaData().getColumnName(i), headerFont)));
            }

            // Data
            while (rs.next()) {
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    table.addCell(new PdfPCell(new Paragraph(rs.getString(i), cellFont)));
                }
            }

            myDocument.add(table);
            myDocument.close();
            JOptionPane.showMessageDialog(null, "Allowance Report Generated");

            rs.close();
            pat.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}

private void generateDeductionReport() {
    JFileChooser dialog = new JFileChooser();
    dialog.setSelectedFile(new File("Deduction Report.pdf"));
    if (dialog.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
        String filePath = dialog.getSelectedFile().getPath();
        try {
            String sql = "SELECT * FROM deduction";
            PreparedStatement pat = conn.prepareStatement(sql);
            ResultSet rs = pat.executeQuery();

            Document myDocument = new Document();
            PdfWriter.getInstance(myDocument, new FileOutputStream(filePath));
            myDocument.open();

            com.itextpdf.text.Font headerFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9, Font.BOLD);
            com.itextpdf.text.Font cellFont   = FontFactory.getFont(FontFactory.TIMES_ROMAN, 8, Font.PLAIN);

            PdfPTable table = new PdfPTable(rs.getMetaData().getColumnCount());
            table.setWidthPercentage(100);

            myDocument.add(new Paragraph("Deduction Report",
                    FontFactory.getFont(FontFactory.TIMES_BOLD, 20, Font.BOLD)));
            myDocument.add(new Paragraph(
                    new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date())
            ));
            myDocument.add(new Paragraph("----------------------------------------------------------"));

            // Headers
            for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                table.addCell(new PdfPCell(new Paragraph(rs.getMetaData().getColumnName(i), headerFont)));
            }

            // Data
            while (rs.next()) {
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    table.addCell(new PdfPCell(new Paragraph(rs.getString(i), cellFont)));
                }
            }

            myDocument.add(table);
            myDocument.close();
            JOptionPane.showMessageDialog(null, "Deduction Report Generated");

            rs.close();
            pat.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}

public void showDate(){
    Calendar cal =new GregorianCalendar();
    int month =cal.get(Calendar.MONTH);
    int year=cal.get(Calendar.YEAR);
    int day=cal.get(Calendar.DAY_OF_MONTH);
    
    jLabel1.setText((month +1)+"/"+day+"/"+year);
    
  
    
}
 public void showTime() {
    new javax.swing.Timer(1000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            Calendar cal = new GregorianCalendar();
            int second = cal.get(Calendar.SECOND);
            int minute = cal.get(Calendar.MINUTE);
            int hour = cal.get(Calendar.HOUR_OF_DAY); // use 24-hour format
            jLabel2.setText(String.format("%02d:%02d:%02d", hour, minute, second));
        }
    }).start();
}   /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jPanel2 = new javax.swing.JPanel();
        jButton13 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        cmbReports = new javax.swing.JComboBox<>();
        jLabel28 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        lbl_emp = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setForeground(new java.awt.Color(51, 51, 255));
        setMinimumSize(new java.awt.Dimension(1179, 670));
        setResizable(false);
        getContentPane().setLayout(null);

        jPanel2.setBackground(new java.awt.Color(51, 0, 51));
        jPanel2.setBorder(new javax.swing.border.MatteBorder(null));
        jPanel2.setLayout(null);

        jButton13.setBackground(new java.awt.Color(0, 0, 255));
        jButton13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton13.setForeground(new java.awt.Color(255, 255, 255));
        jButton13.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-user-50.png")); // NOI18N
        jButton13.setText("Users");
        jButton13.setBorder(null);
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton13);
        jButton13.setBounds(30, 150, 200, 50);

        jButton12.setBackground(new java.awt.Color(0, 0, 255));
        jButton12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pr/icons/icons8-add-user-45.png"))); // NOI18N
        jButton12.setText("Add User");
        jButton12.setBorder(null);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton12);
        jButton12.setBounds(30, 70, 200, 50);

        jButton1.setBackground(new java.awt.Color(255, 51, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("X");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(830, 10, 60, 40);

        cmbReports.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        cmbReports.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Report", "Employee RP", "Employee Allowance RP", "Employee Deduction RP" }));
        cmbReports.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbReportsActionPerformed(evt);
            }
        });
        jPanel2.add(cmbReports);
        cmbReports.setBounds(550, 10, 230, 30);

        jLabel28.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Home");
        jPanel2.add(jLabel28);
        jLabel28.setBounds(10, 0, 100, 30);

        jLabel3.setFont(new java.awt.Font("SansSerif", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Date:");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(160, 10, 70, 20);

        jLabel7.setFont(new java.awt.Font("SansSerif", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Time:");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(350, 10, 70, 20);

        jLabel2.setFont(new java.awt.Font("SansSerif", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Time");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(420, 10, 180, 20);

        jLabel1.setFont(new java.awt.Font("SansSerif", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("date");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(220, 10, 160, 20);

        jLabel4.setBackground(new java.awt.Color(0, 0, 51));
        jLabel4.setForeground(new java.awt.Color(0, 0, 153));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pr/icons/333.jpg"))); // NOI18N
        jLabel4.setOpaque(true);
        jPanel2.add(jLabel4);
        jLabel4.setBounds(-290, 0, 1210, 660);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(280, 0, 900, 630);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(null);

        jButton2.setBackground(new java.awt.Color(0, 0, 102));
        jButton2.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-employees-55.png")); // NOI18N
        jButton2.setText("Employees");
        jButton2.setBorder(null);
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton2MouseExited(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(40, 120, 200, 50);

        jButton3.setBackground(new java.awt.Color(0, 0, 102));
        jButton3.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-update-50.png")); // NOI18N
        jButton3.setText(" Update Salary");
        jButton3.setBorder(null);
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton3MouseExited(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(40, 330, 200, 50);

        jButton4.setBackground(new java.awt.Color(0, 0, 102));
        jButton4.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-log-out-50.png")); // NOI18N
        jButton4.setText("Log Out");
        jButton4.setBorder(null);
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton4MouseExited(evt);
            }
        });
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4);
        jButton4.setBounds(40, 540, 200, 50);

        jButton6.setBackground(new java.awt.Color(0, 0, 102));
        jButton6.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-less-expensive-electricity-78.png")); // NOI18N
        jButton6.setText("Deduction");
        jButton6.setBorder(null);
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton6MouseExited(evt);
            }
        });
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6);
        jButton6.setBounds(40, 400, 200, 50);

        jButton8.setBackground(new java.awt.Color(0, 0, 102));
        jButton8.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-loan-55.png")); // NOI18N
        jButton8.setText(" Allowance");
        jButton8.setBorder(null);
        jButton8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton8MouseExited(evt);
            }
        });
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton8);
        jButton8.setBounds(40, 260, 200, 50);

        jButton9.setBackground(new java.awt.Color(0, 0, 102));
        jButton9.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-search-50.png")); // NOI18N
        jButton9.setText("  Search");
        jButton9.setBorder(null);
        jButton9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton9MouseExited(evt);
            }
        });
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton9);
        jButton9.setBounds(40, 190, 200, 50);

        jButton17.setBackground(new java.awt.Color(0, 0, 102));
        jButton17.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jButton17.setForeground(new java.awt.Color(255, 255, 255));
        jButton17.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-payment-48.png")); // NOI18N
        jButton17.setText(" Payment");
        jButton17.setBorder(null);
        jButton17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton17MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton17MouseExited(evt);
            }
        });
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton17);
        jButton17.setBounds(40, 470, 200, 50);

        jButton18.setBackground(new java.awt.Color(255, 0, 0));
        jButton18.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jButton18.setForeground(new java.awt.Color(255, 255, 255));
        jButton18.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Downloads\\icons8-home-50.png")); // NOI18N
        jButton18.setText("Home");
        jButton18.setBorder(null);
        jButton18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton18MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton18MouseExited(evt);
            }
        });
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton18);
        jButton18.setBounds(40, 50, 200, 50);

        jLabel25.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Logged as:");
        jPanel1.add(jLabel25);
        jLabel25.setBounds(70, 10, 100, 24);

        lbl_emp.setFont(new java.awt.Font("SansSerif", 0, 18)); // NOI18N
        lbl_emp.setForeground(new java.awt.Color(255, 255, 255));
        lbl_emp.setText("s");
        jPanel1.add(lbl_emp);
        lbl_emp.setBounds(180, 10, 30, 20);

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pr/icons/The Role of Branding in the Age of AI-Generated Content.jpg"))); // NOI18N
        jLabel26.setText("jLabel26");
        jPanel1.add(jLabel26);
        jLabel26.setBounds(-220, 0, 490, 710);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 270, 630);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
new signin().setVisible(true);
this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
new users().setVisible(true);
this.dispose();         // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
  int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to exit?", 
            "Exit Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
    
    if (response == JOptionPane.YES_OPTION) {
        System.exit(0); 
    }
      // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cmbReportsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbReportsActionPerformed
                                            
    String choice = cmbReports.getSelectedItem().toString();
    switch (choice) {
        case "Employee RP":
            generateEmployeeReport();
            break;
        case "Employee Allowance RP":
            generateAllowanceReport();
            break;
        case "Employee Deduction RP":
            generateDeductionReport();
            break;
    }
     // TODO add your handling code here:
    }//GEN-LAST:event_cmbReportsActionPerformed

    private void jButton2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseEntered
        jButton2.setBackground(Color.red);  // TODO add your handling code here:
    }//GEN-LAST:event_jButton2MouseEntered

    private void jButton2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseExited
        jButton2.setBackground(new Color(0, 0, 102));        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2MouseExited

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        new employee().setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseEntered
        jButton3.setBackground(Color.red);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3MouseEntered

    private void jButton3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseExited
        jButton3.setBackground(new Color(0, 0, 102));        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3MouseExited

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new Updatesalary().setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseEntered
        jButton4.setBackground(Color.red);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4MouseEntered

    private void jButton4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseExited
        jButton4.setBackground(new Color(0, 0, 102));        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4MouseExited

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to Log out?",
            "Exit Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (response == JOptionPane.YES_OPTION) {
            new login().setVisible(true);
            this.dispose();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseEntered
        jButton6.setBackground(Color.red);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6MouseEntered

    private void jButton6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseExited
        jButton6.setBackground(new Color(0, 0, 102));        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6MouseExited

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        new Deduction().setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseEntered
        jButton8.setBackground(Color.red);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8MouseEntered

    private void jButton8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton8MouseExited
        jButton8.setBackground(new Color(0, 0, 102));        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8MouseExited

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        new Allowance().setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseEntered
        jButton9.setBackground(Color.red);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9MouseEntered

    private void jButton9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton9MouseExited
        jButton9.setBackground(new Color(0, 0, 102));        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9MouseExited

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        new Search().setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton17MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton17MouseEntered
        jButton17.setBackground(Color.red);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17MouseEntered

    private void jButton17MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton17MouseExited
        jButton17.setBackground(new Color(0, 0, 102));        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17MouseExited

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        new Payment().setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseEntered
        jButton18.setBackground(Color.red);       // TODO add your handling code here:
    }//GEN-LAST:event_jButton18MouseEntered

    private void jButton18MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton18MouseExited
        jButton18.setBackground(new Color(0, 0, 102));     // TODO add your handling code here:
    }//GEN-LAST:event_jButton18MouseExited

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        new dashbord().setVisible(true);
        this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton18ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new dashbord().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbReports;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lbl_emp;
    // End of variables declaration//GEN-END:variables
}
