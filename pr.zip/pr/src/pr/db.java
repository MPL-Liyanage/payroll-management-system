/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pr;
import java.sql.*;
import javax.swing.*;
import javax.swing.JOptionPane;
/**
 *
 * @author ASUS
 */
public class db {
    
    Connection conn =null;
    public static Connection java_db(){
    
    try{
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/payroll","root","");
    return conn;
    }catch (Exception e){
        JOptionPane.showMessageDialog(null,e);
        return null;
    }
}
    }